package niven.discordbot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.ExecutionException;


import de.btobastian.javacord.DiscordAPI;
import de.btobastian.javacord.entities.message.Message;
import de.btobastian.javacord.listener.message.MessageCreateListener;

public class Resistance {
	private DiscordAPI api;
	
	private String id;
	
	private ArrayList<String> players;
	private ArrayList<String> players_on_missions;
	private ArrayList<Integer> missions;
	private ArrayList<String> spies;
	private ArrayList<String> votes;
	
	private boolean lady = false;
	private boolean assassin = false;
	private boolean merlin = false;
	
	private String last_message;
	
	private int yes;
	private int no;
	private int pass;
	private int fail;
	
	private int total_pass;
	private int total_fail;
	
	private boolean voting;
	private boolean passfail;
	
	private String current_players;
	
	private int current_mission;
	private int current_try;
	
	private int starter;
	private int hammer;
	
	private boolean in_progress;
	
	private String mission_players = null;
	private String[] mis = null;
	private ArrayList<String> tempList;
	
	public Resistance(DiscordAPI api, Message msg) {
		this.api = api;
		api.registerListener(new MessageCreateListener() {

			public void onMessageCreate(DiscordAPI api, Message msg) {
				checkCommand(api, msg);
			}
			
		});
		
		id_check(api, msg);
	}
	
	public void id_check(DiscordAPI api, Message msg) {
		msg.reply("Please enter the server ID you wish to play on prefixed with '$'\n" + api.getChannels().toString());
	}
	
	private void initialize(DiscordAPI api, Message msg) {
		players = new ArrayList<String>();
		spies = new ArrayList<String>();
		players_on_missions = new ArrayList<String>();
		missions = new ArrayList<Integer>();
		votes = new ArrayList<String>();
		tempList = new ArrayList<String>();
		current_players = "";
		starter = 0;
		hammer = 0;
		current_mission = 1;
		yes = 0;
		no = 0;
		fail = 0;
		pass = 0;
		total_pass = 0;
		total_fail = 0;
		voting = false;
		passfail = false;
		current_try = 0;
		in_progress = false;
		last_message = "";
		
		last_message = "~--===--~ RESISTANCE ~--===--~\n"
				+ "Who would like to join? Type '$me' to join, '$start' to start the game, or '$help' for help";
		api.getChannelById(id).sendMessage(last_message);
		
	}
	
	private void checkCommand(DiscordAPI api, Message msg) {
		if(msg.getContent().equalsIgnoreCase("$help")) {
			api.getChannelById(id).sendMessage("```                          Commands\n"
					+ "--- GLOBAL ---\n"
					+ "'$help'                  : displays available commands\n"
					+ "'$sayagain'             : shows last said message\n"
					+ "'$reload'                : reloads game\n"
					+ "'$start'                 : starts game (pregame only)\n"
					+ "'$me'                    : joins game (pregame only)	\n"
					+ "--- PLAYING ---\n"
					+ "'$name name name...'     : chooses players for team\n"
					+ "'$yes'                   : votes yes for current team\n"
					+ "'$no'                    : votes no for current team\n"
					+ "'$pass'                  : decides to pass current mission\n"
					+ "'$fail'                  : decides to fail current mission\n"
					+ "'$mission#'              : shows players from specified mission (ex. $mission2)\n"
					+ "\n                          Info\n"
					+ "Underlined missions indicates current mission\n"
					+ "First number indicates mission number\n"
					+ "Second number indicates how many players will be on that mission\n"
					+ "P or F will appear next to missions if they pass or fail```");
		}
		
		else if(msg.getContent().equalsIgnoreCase("$reload")) {
			initialize(api, msg);
		}
		
		else if(msg.getContent().equalsIgnoreCase("$sayagain")) {
			api.getChannelById(id).sendMessage(last_message);
		}
		
		
		else if(!in_progress) {
			if(msg.getContent().equalsIgnoreCase("$me")) {
				players.add(msg.getAuthor().getId());
				
				current_players = "";
				for(int x = 0; x < players.size(); x++) {
					try {
						current_players += api.getUserById(players.get(x)).get().getName();
						if(x != players.size() - 1)
							current_players += ", ";
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (ExecutionException e) {
						e.printStackTrace();
					}
				}
				
				last_message = "~--===--~ RESISTANCE ~--===--~\n" + getUser(api, msg) + " added!\nCurrent players: " + current_players.toUpperCase();
				api.getChannelById(id).sendMessage(last_message);
			}
			
			else if(msg.getContent().equalsIgnoreCase("$start")) {
				start(api, msg);
			}
			
			else if(msg.getContent().startsWith("$") && !msg.getContent().equalsIgnoreCase("$stop")) {
				id = msg.getContent().substring(1);
				initialize(api, msg);
			}
		}
		
		
		else if(in_progress) {
			
			
			if(msg.getContent().split(" ").length >= 2 && msg.getAuthor().getId().equals(players.get(starter)) && msg.getContent().startsWith("$")) {
				mission_players = msg.getContent().substring(1);
				boolean dne = false;
				mis = mission_players.split(" ");
				
				ArrayList<String> names = new ArrayList<String>();
				for(int x = 0; x < players.size(); x++) {
					try {
						names.add(api.getUserById(players.get(x)).get().getName());
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (ExecutionException e) {
						e.printStackTrace();
					}
				}
				
				for(int x = 0; x < mis.length; x++) {
					if(!names.contains(mis[x])) {
						dne = true;
						last_message = msg.getAuthor().getName().toUpperCase() + ", " + mis[x] + " does not exist. Please type the names correctly, prefixed with '$'. Current players: " + current_players.toUpperCase();
						api.getChannelById(id).sendMessage(last_message);
					}
				}
				
				if(!dne) {
					String list = "";
					for(int x = 0; x < mis.length; x++) {
						list += mis[x];
						if(x != mis.length - 1)
							list += ", ";
					}
					
					last_message = msg.getAuthor().getName().toUpperCase() + " has chosen " + list.toUpperCase() + " for their team. PM me '$yes' or '$no' to vote.";
					api.getChannelById(id).sendMessage(last_message);
					voting = true;
					yes = 0;
					no = 0;
					pass = 0;
					fail = 0;
				}
			}
			
			
			else if(msg.getContent().startsWith("$mission")) {
				String mission = msg.getContent();
				int num = Integer.parseInt(mission.substring(8));
				if(missions.get(num-1) == 0) {
					last_message = "Mission " + num + " failed with " + players_on_missions.get(num-1).toString().toUpperCase();
					api.getChannelById(id).sendMessage(last_message);
				}
				if(missions.get(num-1) == 1) {
					last_message = "Mission " + num + " passed with " + players_on_missions.get(num-1).toString().toUpperCase();
					api.getChannelById(id).sendMessage(last_message);
				}
				if(missions.get(num-1) == 2) {
					last_message = "Mission " + num + " failed with " + players_on_missions.get(num-1).toString().toUpperCase() + " and had 2 failures";
					api.getChannelById(id).sendMessage(last_message);
				}
			}
			
			
			else if(msg.getContent().startsWith("$")) {
				
				if(voting) {
					if(votes.contains(msg.getAuthor().getId()))
						msg.reply("You have already voted!");
					else if(msg.getContent().equalsIgnoreCase("$yes")) {
						yes++;
						votes.add(msg.getAuthor().getId());
					}
					else if(msg.getContent().equalsIgnoreCase("$no")) {
						no++;
						votes.add(msg.getAuthor().getId());
					}
					
					if((yes + no) != players.size()) {
						ArrayList<String> temp = new ArrayList<String>();
						temp.addAll(players);
						temp.removeAll(votes);
						String list = "";
						
						for(int x = 0; x < temp.size(); x++) {
							try {
								list += api.getUserById(temp.get(x)).get().getName();
							} catch (InterruptedException e) {
								e.printStackTrace();
							} catch (ExecutionException e) {
								e.printStackTrace();
							}
							if(x != temp.size() - 1)
								list += ", ";
						}
						
						last_message = (yes + no) + "/" + players.size() + " votes in. Waiting for " + list + "...";
						api.getChannelById(id).sendMessage(last_message);
					}
					else {
						if(yes > no) {
							last_message = "Mission is going through with " + yes + " to " + no + " votes.\n"
									+ "Players on mission: " + mission_players.toUpperCase() + "\n"
									+ "PM me '$pass' or '$fail'";
							api.getChannelById(id).sendMessage(last_message);
							voting = false;
							passfail = true;
							tempList = new ArrayList<String>(Arrays.asList(mission_players.split(" ")));
						}
						else {
							starter++;
							if(starter >= players.size())
								starter = 0;
							current_try++;
							if((5 - current_try) == 1) {
								last_message = "Mission not going through with " + no + " to " + yes + " votes.\n"
										+ "Last try.";
								api.getChannelById(id).sendMessage(last_message);
								voting = false;
								votes = new ArrayList<String>();
								turn(msg);
							}
							else if((5 - current_try) == 0) {
								last_message = "**SPIES** won! The vote didn't go through with " + no + " to " + yes + " votes.";
								api.getChannelById(id).sendMessage(last_message);
								in_progress = false;
							}
							else {
								last_message = "Mission not going through with " + no + " to " + yes + " votes.\n"
										+ "**" + (5 - current_try) + "** tries remaining.";
								api.getChannelById(id).sendMessage(last_message);
								voting = false;
								votes = new ArrayList<String>();
								turn(msg);
							}
						}
					}
				}
				
				else if((msg.getContent().equalsIgnoreCase("$pass") || msg.getContent().equalsIgnoreCase("$fail")) && passfail) {
					if(msg.getContent().equalsIgnoreCase("$pass")) {
						if(!tempList.contains(msg.getAuthor().getName())) {
							msg.reply("Cannot vote!");
						}
						else {
							pass++;
							tempList.remove(msg.getAuthor().getName());
						}
					}
					else if(msg.getContent().equalsIgnoreCase("$fail")) {
						if(!spies.contains(msg.getAuthor().getId())) {
							msg.reply("You cannot fail a mission if you are a RESISTANCE member.");
						}
						else {
							if(!tempList.contains(msg.getAuthor().getName())) {
								msg.reply("Cannot vote!");
							}
							else {
								fail++;
								tempList.remove(msg.getAuthor().getName());
							}
						}
					}
					
					if(mis != null && (pass + fail) != mis.length) {
						last_message = (pass + fail) + "/" + mis.length + " decisions made.";
						api.getChannelById(id).sendMessage(last_message);
					}
					else {
						if(fail == 1) {
							last_message = "Mission __FAILED__";
							api.getChannelById(id).sendMessage(last_message);
							missions.add(0);
							current_mission++;
							total_fail++;
						}
						else if(fail == 2) {
							last_message = "Mission __FAILED__ with 2 failures";
							api.getChannelById(id).sendMessage(last_message);
							missions.add(2);
							current_mission++;
							total_fail++;
						}
						else if(fail == 0 && pass >= 1){
							last_message = "Mission __PASSED__";
							api.getChannelById(id).sendMessage(last_message);
							missions.add(1);
							current_mission++;
							total_pass++;
							
						}
						
						votes = new ArrayList<String>();
						tempList = new ArrayList<String>();
						passfail = false;
						current_try = 0;	
						starter++;
						if(starter >= players.size())
							starter = 0;
						players_on_missions.add(mission_players);
						
						if(total_pass >= 3) {
							last_message = "The **RESISTANCE** have won!";
							api.getChannelById(id).sendMessage(last_message);
							in_progress = false;
						}
						else if(total_fail >= 3) {
							last_message = "The **SPIES** have won!";
							api.getChannelById(id).sendMessage(last_message);
							in_progress = false;
						}
						else
							turn(msg);
					}
				}
			}
		}
	}
	
	private String getUser(DiscordAPI api, Message msg) {
		String user = "null";
		try {
			user = api.getUserById(msg.getAuthor().getId()).get().getName();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
		return user;
	}
	
	private void start(DiscordAPI api, Message msg) {
		if(players.size() < 5) {
			last_message = "Error: Needs at least 5 to start! There are currently " + players.size() + " players.";
			api.getChannelById(id).sendMessage(last_message);
		}
		else if(players.size() > 10) {
			last_message = "Error: Maximum of 10 players! There are currently " + players.size() + " players.";
			api.getChannelById(id).sendMessage(last_message);
		}
		
		else {
			in_progress = true;
			
			assign_roles((int) (Math.ceil((double) (players.size()/3.0))));
			
			Random r = new Random();
			starter = r.nextInt(players.size());
			hammer = starter;
			for(int x = 0; x < 5; x++) {
				hammer++;
				if(hammer >= players.size())
					hammer = 0;
			}

			last_message = "~--===--~ RESISTANCE ~--===--~\n"
					+ "Game in progress. Please check your PM from me! Type '$help' for help.\nNumber of spies: **" + (int) (Math.ceil((double) (players.size()/3.0))) + "**";
			api.getChannelById(id).sendMessage(last_message);
	
			turn(msg);
			}
	}
	
	private void turn(Message msg) {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		try {
			last_message = "Current players: " + current_players.toUpperCase() + "\nMissions: " + missionString() + "\n\n"
					+ api.getUserById(players.get(starter)).get().getName().toUpperCase() + " is choosing the team.";
			api.getChannelById(id).sendMessage(last_message);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		} catch (ExecutionException e1) {
			e1.printStackTrace();
		}
		
	}
	
	private void assign_roles(int num) {
		Random ran = new Random();
		int remain = num;
		int index = 0;
		
		Collections.shuffle(players);

		while(remain != 0) {
			if(ran.nextBoolean()) {
				if(index >= players.size())
					index = 0;
				if(!spies.contains(players.get(index))) {
					spies.add(players.get(index));
					remain--;
					index++;
				}
			}
			else {
				index++;
			}
		}
		
		for(int x = 0; x < players.size(); x++) {
			try {
				if(spies.contains(players.get(x))) {
					api.getUserById(players.get(x)).get().sendMessage("You are a SPY!");
				}
				else {
					api.getUserById(players.get(x)).get().sendMessage("You are RESISTANCE!");
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
		}
	}
	
	private String missionString() {
		String result = "| ";
		int num = players.size();

		for(int x = 1; x < 6; x++) {
			if(current_mission == x)
				result += "__";
			
			result += x + "-";
			
			if((x-1) < missions.size() && (missions.get(x-1) == 0 || missions.get(x-1) == 2)) {
				result += "***F*** ";
			}
			else if((x-1) < missions.size() && (missions.get(x-1) == 1)) {
				result += "***P***";
			}
			else {
				if(num == 5) {
					if(x == 1 || x == 3)
						result += "2";
					if(x == 2 || x == 4 || x == 5)
						result += "3";
				}
				if(num == 6) {
					if(x == 1)
						result += "2";
					if(x == 2 || x == 4)
						result += "3";
					if(x == 3 || x == 5)
						result += "4";
				}
				if(num == 7) {
					if(x == 1)
						result += "2";
					if(x == 2 || x == 3)
						result += "3";
					if(x == 4)
						result += "4*";
					if(x == 5)
						result += "4";
				}
				if(num >= 8) {
					if(x == 1)
						result += "3";
					if(x == 2 || x == 3)
						result += "4";
					if(x == 4)
						result += "5*";
					if(x == 5)
						result += "5";
				}
				if(current_mission == x)
					result += "__";
			}
			
			result += "  |  ";
		}
		
		return result;
	}
}
