package niven.discordbot;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.Random;
import java.util.concurrent.ExecutionException;

import com.google.common.util.concurrent.FutureCallback;

import de.btobastian.javacord.DiscordAPI;
import de.btobastian.javacord.Javacord;
import de.btobastian.javacord.entities.Channel;
import de.btobastian.javacord.entities.Server;
import de.btobastian.javacord.entities.message.Message;
import de.btobastian.javacord.listener.message.MessageCreateListener;

public class Nivbot {

	private final String token = /* REPLACE WITH YOUR TOKEN HERE; */
	
	private Resistance res;
	private boolean newgame_res;
	
	public static void main(String[] args) {
		new Nivbot();
	}
	
	public Nivbot() {
		initialize();
	}
	
	/*
	 * ---- INITIALIZE ----
	 * Initializes the bot, connects to server, and listens to messages
	 */
	
	private void initialize() {
		newgame_res = true;
		
		DiscordAPI api = Javacord.getApi(token, true);
		api.connect(new FutureCallback<DiscordAPI>() {
			public void onFailure(Throwable t) {
				t.printStackTrace();
			}
			
			public void onSuccess(DiscordAPI api) {
				api.registerListener(new MessageCreateListener() {

					public void onMessageCreate(DiscordAPI api, Message msg) {
						checkCommand(api, msg);
					}
				});
			}
		});
	}
	
	private void checkCommand(DiscordAPI api, Message msg) {
		if(msg.getContent().equalsIgnoreCase("!commands") || msg.getContent().equalsIgnoreCase("!help")) {
			msg.reply("```'!flip'                  : flips a coin\n"
					+ "'!roll #'                : rolls a number between 1-#\n"
					+ "'!roll # $'              : rolls a number between #-$\n"
					+ "'!uptime'                : shows how long I've been alive\n"
					+ "'!resistance'            : starts a game of Resistance\n"
					+ "\n                       Version 0.8.9\n"
					+ "        Last update: Resistance base game completed```");
		}
		
		else if(msg.getContent().equalsIgnoreCase("!flip")) {
			flip(msg);
		}
		
		else if(msg.getContent().startsWith("!roll")) {
			roll(msg.getContent(), msg);
		}
		
		else if(msg.getContent().equalsIgnoreCase("!uptime")) {
			uptime(msg);
		}
		
		else if(msg.getContent().equalsIgnoreCase("!resistance")) {
			resistance(api, msg);
		}
		
		else if(msg.getContent().equalsIgnoreCase("!test")) {
			test(api, msg);
		}
		
		else if(msg.getContent().startsWith("!")) {
			msg.reply("Invalid command, " + msg.getAuthor().getName() + ". Type '!commands' to see what I can do.");
		}
	}
	
	/*
	 * ---- FLIP ----
	 * Flips a coin
	 */
	
	private void flip(Message msg) {
		Random r = new Random();
		int result = r.nextInt(2);
		
		if(result == 0) {
			msg.reply(msg.getAuthor().getName() + " flipped HEADS.");
		}
		
		else {
			msg.reply(msg.getAuthor().getName() + " flipped TAILS.");
		}
	}
	
	/*
	 * ---- ROLL ----
	 * Rolls a number between two numbers
	 */
	
	private void roll(String arg, Message msg) {
		String[] input = arg.split(" ");
		Random r = new Random();
		
		if(input.length == 2) {
			try {
				int num = r.nextInt(Integer.parseInt(input[1])) + 1;
				msg.reply(msg.getAuthor().getName() + " rolled " + num + ".");
			} catch(Exception e) {
				msg.reply("Input error: input must either be '!roll #' or '!roll # $'.");
			}
		}
		
		else if(input.length == 3) {
			try {
				int low = Integer.parseInt(input[1]);
				int high = Integer.parseInt(input[2]) + 1;
				int num = r.nextInt(high - low) + low;
				msg.reply(msg.getAuthor().getName() + " rolled " + num + ".");
			} catch(Exception e) {
				msg.reply("Input error: input must either be '!roll #' or '!roll # $'.");
			}
		}
		
		else {
			msg.reply("Input error: input must either be '!roll #' or '!roll # $'.");
		}
	}
	
	/*
	 * ---- UPTIME ----
	 * Shows uptime of bot in server
	 */

	private void uptime(Message msg) {
		RuntimeMXBean rb = ManagementFactory.getRuntimeMXBean();
		long seconds = rb.getUptime()/1000;
		long sec = seconds % 60;
		long minutes = seconds % 3600 / 60;
		long hours = seconds % 86400 / 3600;
		long days = seconds / 86400;
		
		msg.reply("Uptime: " + days + " days, " + hours + " hours, " + minutes + " minutes, " + sec + " seconds.");
	}

	private void resistance(DiscordAPI api, Message msg) {
		if(newgame_res) {
			res = new Resistance(api, msg);
			newgame_res = false;
		}
		else {
			res.id_check(api, msg);
		}
	}
	
	/*
	 * ---- TEST ----
	 * Used for testing purposes
	 */
	
	private void test(DiscordAPI api, Message msg) {
		msg.reply(api.getUsers().toString());
	}
}
